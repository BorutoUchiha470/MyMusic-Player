package dev.anilbeesetti.nextplayer.core.ui.glass

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

/**
 * Compiles the glass shaders before anyone sees them.
 *
 * The blur, the lens bend and the colour boost are small GPU programs. Android builds each one the
 * first time it is drawn, which made the very first press on a control (or the first time the
 * controls faded in) stutter while every later one was smooth. This draws two almost invisible
 * panes, one of each glass kind, once, as soon as the player opens - while the video is still
 * starting and a dropped frame goes unnoticed. They are drawn at 1% opacity, which is enough for
 * the programs to be built for real and too faint to see, and they stop being composed after a
 * couple of frames.
 *
 * The panes use the same settings the real controls use, so the exact variants the user has
 * switched on (chromatic edges, depth, frosted, clear...) are the ones that get built.
 */
@Composable
fun GlassWarmUp() {
    if (LocalGlassBackdrop.current == null) return
    val settings = LocalGlassSettings.current ?: return
    var needed by remember { mutableStateOf(true) }
    if (!needed) return
    LaunchedEffect(Unit) {
        // One frame to record the draw, one to be sure it reached the GPU.
        withFrameNanos {}
        withFrameNanos {}
        needed = false
    }
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .size(24.dp)
            .graphicsLayer { alpha = 0.01f }
            .glassSurface(settings),
    )
    Box(
        Modifier
            .size(24.dp)
            .graphicsLayer { alpha = 0.01f }
            .glassPanel(
                shape = shape,
                tint = Color.Transparent,
                fallbackColor = Color.Transparent,
            ),
    )
}
