package dev.anilbeesetti.nextplayer.settings.screens.player

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.extras.rememberExtraFeatures
import dev.anilbeesetti.nextplayer.settings.screens.appearance.SwitchRow

/** On/off switches for the extra features added to the player. */
@Composable
fun ExtraFeaturesSettings(modifier: Modifier = Modifier) {
    val extras = rememberExtraFeatures()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SwitchRow(
            title = stringResource(R.string.extra_seek_preview),
            description = stringResource(R.string.extra_seek_preview_desc),
            checked = extras.seekPreview,
            onCheckedChange = { extras.updateSeekPreview(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_capture_buttons),
            description = stringResource(R.string.extra_capture_buttons_desc),
            checked = extras.captureButtons,
            onCheckedChange = { extras.updateCaptureButtons(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_sleep_timer),
            description = stringResource(R.string.extra_sleep_timer_desc),
            checked = extras.sleepTimerButton,
            onCheckedChange = { extras.updateSleepTimerButton(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_fast_skip),
            description = stringResource(R.string.extra_fast_skip_desc),
            checked = extras.fastSkip,
            onCheckedChange = { extras.updateFastSkip(it) },
        )
    }
}
