package dev.anilbeesetti.nextplayer.core.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.highlight.Highlight
import com.kyant.backdrop.shadow.Shadow

/**
 * Slider with a rounded colored track and a white pill thumb. While it is held the thumb turns
 * into a glass bubble that bends the track behind it.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiquidSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
    onValueChangeFinished: (() -> Unit)? = null,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val isDragged by interactionSource.collectIsDraggedAsState()
    val press by animateFloatAsState(
        targetValue = if (isPressed || isDragged) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "liquidSliderPress",
    )
    val trackBackdrop = rememberLayerBackdrop()
    val accent = MaterialTheme.colorScheme.primary
    val inactive = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)

    Slider(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        enabled = enabled,
        valueRange = valueRange,
        steps = steps,
        onValueChangeFinished = onValueChangeFinished,
        interactionSource = interactionSource,
        thumb = {
            Box(
                modifier = Modifier
                    .drawBackdrop(
                        backdrop = trackBackdrop,
                        shape = { CircleShape },
                        effects = {
                            blur(6.dp.toPx() * (1f - press))
                            lens(
                                refractionHeight = 6.dp.toPx() * press,
                                refractionAmount = 12.dp.toPx() * press,
                                chromaticAberration = true,
                            )
                        },
                        highlight = { Highlight.Ambient.copy(alpha = press.coerceIn(0f, 1f)) },
                        shadow = { Shadow(radius = 4.dp, color = Color.Black.copy(alpha = 0.15f)) },
                        layerBlock = {
                            val scale = lerp(1f, 1.25f, press)
                            scaleX = scale
                            scaleY = scale
                        },
                        onDrawSurface = {
                            drawRect(Color.White.copy(alpha = 1f - press * 0.85f))
                        },
                    )
                    .size(width = 36.dp, height = 24.dp),
            )
        },
        track = { sliderState ->
            val span = sliderState.valueRange.endInclusive - sliderState.valueRange.start
            val fraction = if (span > 0f) {
                ((sliderState.value - sliderState.valueRange.start) / span).coerceIn(0f, 1f)
            } else {
                0f
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .layerBackdrop(trackBackdrop)
                    .clip(CircleShape)
                    .drawBehind {
                        drawRect(color = inactive)
                        drawRect(
                            color = accent,
                            topLeft = Offset.Zero,
                            size = Size(width = size.width * fraction, height = size.height),
                        )
                    },
            )
        },
    )
}
