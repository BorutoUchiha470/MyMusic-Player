package dev.anilbeesetti.nextplayer.core.ui.extras

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext

const val EXTRA_FEATURES_PREFS = "extra_features"
const val KEY_FAST_SKIP = "fast_skip"
private const val KEY_SEEK_PREVIEW = "seek_preview"
private const val KEY_CAPTURE_BUTTONS = "capture_buttons"
private const val KEY_SLEEP_TIMER = "sleep_timer_button"

/** On/off switches for the extra features added to the player. Everything is on by default. */
@Stable
class ExtraFeatures(private val prefs: SharedPreferences) {
    var seekPreview by mutableStateOf(prefs.getBoolean(KEY_SEEK_PREVIEW, true))
        private set
    var captureButtons by mutableStateOf(prefs.getBoolean(KEY_CAPTURE_BUTTONS, true))
        private set
    var sleepTimerButton by mutableStateOf(prefs.getBoolean(KEY_SLEEP_TIMER, true))
        private set
    var fastSkip by mutableStateOf(prefs.getBoolean(KEY_FAST_SKIP, true))
        private set

    fun updateSeekPreview(value: Boolean) {
        seekPreview = value
        prefs.edit().putBoolean(KEY_SEEK_PREVIEW, value).apply()
    }

    fun updateCaptureButtons(value: Boolean) {
        captureButtons = value
        prefs.edit().putBoolean(KEY_CAPTURE_BUTTONS, value).apply()
    }

    fun updateSleepTimerButton(value: Boolean) {
        sleepTimerButton = value
        prefs.edit().putBoolean(KEY_SLEEP_TIMER, value).apply()
    }

    fun updateFastSkip(value: Boolean) {
        fastSkip = value
        prefs.edit().putBoolean(KEY_FAST_SKIP, value).apply()
    }
}

@Composable
fun rememberExtraFeatures(): ExtraFeatures {
    val context = LocalContext.current
    return remember {
        ExtraFeatures(
            context.applicationContext.getSharedPreferences(EXTRA_FEATURES_PREFS, Context.MODE_PRIVATE),
        )
    }
}

/** Provided by the player screen so the controls can check which extras are switched on. */
val LocalExtraFeatures = staticCompositionLocalOf<ExtraFeatures?> { null }
